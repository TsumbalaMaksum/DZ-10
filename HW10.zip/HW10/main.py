import sqlite3

connection = sqlite3.connect('zrs.sl3', 5)
cur = connection.cursor()
# cur.execute("CREATE TABLE first_table (time TEXT);")
cur.execute("INSERT INTO first_table (date) VALUES ('04.03.2023');")
connection.commit()


connection.close()